## Hello Worldの表示
まずは、Hello Worldを表示してみましょう。  
「6.環境構築」を飛ばして読んでいる場合は、以下コマンドでDjangoプロジェクトを作成してください。
```
django-admin startproject simpletodo
cd simpletodo
python manage.py startapp todo
python manage.py runserver
```

todo/views.pyに、以下プログラムを追加します。  
```python hl_lines="2 6 7"
# todo/views.py
from django.http import HttpResponse
from django.shortcuts import render


def index(request):
    return HttpResponse('Hello, world!')
```

!!! note
    Djangoは、MVCではなくMTVモデルを採用しています。 
    今回修正したviews.pyは、MVCモデルで言うとControllerの部分になります。
    
    index(request)でリクエストを受けた後、return HttpResponse()でレスポンスを返しています。

todo/urls.pyというファイルを追加して、以下のプログラムを作成します。
```python
# todo/urls.py
from django.urls import path

from todo import views

app_name = 'todo'
urlpatterns = [
    path('', views.index, name='index'),
]
```

simpletodo/urls.pyに、以下プログラムを追加します。  
```python hl_lines="3 7"
# simpletodo/urls.py
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('todo.urls')),
]
```

Djangoが起動している場合は、自動でサーバが再起動されます。  
<a href="http://localhost:8000">http://localhost:8000</a>にアクセスして、Hello, world! が表示できたら完了です。

## HTMLの表示
Adobe XD のモックアップを見て、HTMLをコーディングします。  
今回は、HTMLを用意したので、これを表示させてみましょう。  
[HTML(html.zip)のダウンロード](zip/html.zip)

!!! 課題
    もし自信があれば、自分でHTMLをコーディングしてみてください。

todoフォルダ直下に、html.zipのstaticとtemplatesフォルダ配下をコピーしてください。
フォルダ構成は、以下のようになります。  
```
todo/  
  static/  
    todo/  
      ...
  templates/
    todo/
      index.html  
```

todo/views.pyを、以下のように変更します。  
```python hl_lines="7"
# todo/views.py
from django.http import HttpResponse
from django.shortcuts import render


def index(request):
    return render(request, 'todo/index.html')
```

simpletodo/settings.pyに、以下プログラムを追加します。  
```python hl_lines="3"
# simpletodo/settings.py
INSTALLED_APPS = [
    'todo.apps.TodoConfig',
    'django.contrib.admin',
```

<a href="http://localhost:8000">http://localhost:8000</a>にアクセスして、HTMLが表示できたら完了です。  
<span style="max-width:300px; display:block;">
![](img/simpletodo/completed.png)
</span>

次は、DjangoでDB管理をします。
