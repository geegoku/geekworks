## モックアップとは
モックアップとは、ワイヤーフレームに配色やスタイルを追加して、完成物を視覚的に表現したものです。
この制作ツールとして、特に有名なのが
<a href="https://www.sketchapp.com/" target="_blank">Sketch</a>
と
<a href="https://www.adobe.com/jp/products/xd.html" target="_blank">Adobe XD</a>です。

## 余談
現在のシェア的には、Sketchが多いのですが、Adobe XDは無料でもほとんどの機能が使えるので、
今後はAdobe XDのシェアが増えるかもしれません。  
ただし、現時点(2018/07)だと「Adobe XDから→html出力ができない」ので、htmlとcssは自分でガリガリ書く必要があります。

ちなみに、リクルートだと以下のようなシェアだそうです。
![](https://s3-ap-northeast-1.amazonaws.com/techblog.bucket/wp-content/uploads/2017/12/blog_all1.png)

## モックアップの作成
今回は、Adobe XDでモックアップを作成します。
作成したワイヤーフレームを参考に、実際の画像を貼り付け、完成イメージに近づけます。

作成したモックアップは、以下のようになります。  

![](img/simpletodo/mockup.png)

制作物のイメージが明確化したところで、実際にDjangoでアプリを作ってみましょう。  
次は、Djangoの開発環境を構築します。