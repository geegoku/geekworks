## Pythonのインストール
まず、<a href="https://www.python.org/downloads/" target="_blank">
Python
</a>
のインストールをします。  

!!! Windowsの場合
    インストール方法は、以下が参考になります。  
    <a href="https://qiita.com/taiponrock/items/f574dd2cddf8851fb02c" target="_blank">
      Pythonをインストールする（for Windows)
    </a>

!!! Macの場合
    最新のMacの場合は、以下のコマンドを実行して、Python3.xが入っていれば問題ありません。  
    ```
    python --version
    ```

## PyCharmのインストール
PythonのIDEは、一番メジャーな
<a href="https://www.jetbrains.com/pycharm/download/" target="_blank">
PyCharm Community
</a>
をインストールします。

!!! Windowsの場合
    インストール方法は、以下が参考になります。  
    <a href="https://pythondatascience.plavox.info/python%E3%81%AE%E9%96%8B%E7%99%BA%E7%92%B0%E5%A2%83/pycharm%E3%81%AE%E3%82%A4%E3%83%B3%E3%82%B9%E3%83%88%E3%83%BC%E3%83%AB" target="_blank">
      PyCharm のインストール(Windows)
    </a>  

!!! Macの場合
    <a href="http://sasshi.info/pycharm_install-2-2042" target="_blank">
      PyCharm のインストール(Mac)
    </a>

!!! info "PyCharmを日本語化したい場合"
    PyCharmを日本語化したい場合は、
    <a href="http://mergedoc.osdn.jp/" target="_blank">
      Pleiades プラグイン
    </a>
    で日本語にできます。

## Djangoのインストール
コマンドラインから、以下を実行してください。
```
pip install django
```
 
!!! question "Windowsでエラーになったら"
    Pythonインストール時、「Add Python 3.x to PATH」にチェックを入れたか確認してください。  
    <a href="https://qiita.com/taiponrock/items/f574dd2cddf8851fb02c" target="_blank">
      Pythonをインストールする（for Windows)
    </a>

!!! question "Macでエラーになったら"
    sudoで実行してください。  
    ```
    sudo pip install django
    ```


## Djangoでプロジェクトの作成
プロジェクトを作成したい場所に移動して、以下コマンドを実行してください。

```
django-admin startproject simpletodo
cd simpletodo
python manage.py startapp todo
```

<code>
  django-admin <font color="red">startproject</font> プロジェクト名
</code>
は、プロジェクトを作成するコマンドです。  
<code>
  python manage.py <font color="red">startapp</font> アプリ名
</code>
は、アプリを作成するコマンドです。

!!! info "プロジェクトとアプリの違いについて"
    Djangoでは1つのプロジェクトに対して、複数のアプリを入れることができます。  
    ここで言うプロジェクトは「サイト」、アプリが「機能」と考えてください。  
    例えば、facebookがDjangoで作られていた場合、以下のような構成になります。  

    facebook (プロジェクト)  
    &nbsp;&nbsp; users (アプリ)  
    &nbsp;&nbsp; events (アプリ)  
    &nbsp;&nbsp; messages (アプリ)  
    &nbsp;&nbsp; ...

!!! warning
    プロジェクト名とアプリ名には、小文字の半角英数字のみを使用してください。  
    ハイフン「-」やアンダーバー「_」は、使わないでください。(使ってしまうと、後々めんどいです)  

    <code>
    django-admin startproject <span style="color:red;">simple-todo</span> (ダメな例)  
    python manage.py startapp <span style="color:red;">to_do</span>　(ダメな例)
    </code>


コマンドで、Djangoを起動します。    
```
python manage.py runserver
```

localhostにアクセスして、Djangoが起動していたら完了です。

<span style="width:550px; display:block;">
<a href="http://localhost:8000/" target="_blank">
  http://localhost:8000/  
  ![](img/django.png)
</a>
</span>

「Cntrl + C」でDjangoを終了したら、次はDjangoの準備をします。
