## リクエストの作成
「3.ワイヤーフレーム」を思い返して、Todoアプリに必要なPathを抽出します。

|  機能   |   Path  | リダイレクト     | 画面 |
|:-------:|:------:|:---------------|:----:| 
| 一覧表示 | /index | 無し            | 有り |
|   追加  | /create | 有り(一覧表示へ) | 無し |
|   更新  | /update | 有り(一覧表示へ) | 無し |
|   削除  | /delete | 有り(一覧表示へ) | 無し |

上記を元に、todo/urls.pyにプログラムを追加します。  
```python hl_lines="9 10 11"
# todo/urls.py
from django.urls import path

from todo import views

app_name = 'todo'
urlpatterns = [
    path('', views.index, name='index'),
    path('create', views.create, name='create'),
    path('<int:post_id>/update', views.update, name='update'),
    path('<int:post_id>/delete', views.delete, name='delete'),
]
```

!!! Note
    Django2.xでIDを受け渡す時は、<code>&lt;int:<font color="red">変数名</font>></code>とします。(過去のDjangoだと、正規表現が必要でした)  

    ここで指定した変数名が、views.pyで受け取れます。    
    例えば<code>&lt;int:<font color="red">hoge_id></font></code>とした場合、views.pyでは以下で受け取れます。  
    <code>
    def update(request, <font color="red">hoge_id</font>):  
    def delete(request, <font color="red">hoge_id</font>):  
    </code>


todo/views.pyを、以下プログラムに入れ替えます。
```python
# todo/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from random import randrange

from todo.forms import PostForm
from todo.models import Post

messages = [
    '頑張ってね。応援してるよ！',
    '君はタスク管理が得意な フレンズなんだね',
    'すごーい！',
    'たーのしー！',
    ''
]


def index(request):
    posts = Post.objects.order_by('-created_at')
    if len(posts) == 0:
        message = 'タスクを追加してね'
    else:
        dice = randrange(len(messages))
        message = messages[dice]
    context = {
        'posts': posts,
        'message': message
    }
    return render(request, 'todo/index.html', context)


def create(request):
    form = PostForm(request.POST)
    if form.is_valid():
        form.save()
    return redirect(reverse('todo:index'))


def update(request, post_id):
    post = get_object_or_404(Post, pk=post_id)
    post.completed = not post.completed
    post.save()
    return redirect(reverse('todo:index'))


def delete(request, post_id):
    post = get_object_or_404(Post, pk=post_id)
    post.delete()
    return redirect(reverse('todo:index'))
```

!!! Note "def index(request)のプログラムについて"
    Djangoでは、ORM(オブジェクト関係マッピング)でDBを操作します。
    
    <code>Post.objects.<font color="red">all()</font></code> ... 全件取得する  
    <code>Post.objects.<font color="red">order_by('-created_at')</font></code> ... 登録日の降順で全件取得する  
    ※ ORMで使用できるメソッドについては、<a href="https://qiita.com/okoppe8/items/66a8747cf179a538355b">ここに</a>一覧で載っています。
    
    ORMで取得した値を、render()の第三引数に渡すことで、HTML内から参照できるようになります。  
    <code>
    <font color="red">posts</font> = Post.objects.all()  
    return render(request, 'todo/index.html', {'posts': <font color="red">posts</font>})
    </code>

todo/forms.pyというファイルを追加して、以下のプログラムを作成します。
```python
# todo/forms.py
from django.forms import ModelForm

from todo.models import Post


class PostForm(ModelForm):
    class Meta:
        model = Post
        fields = ('task', 'completed')
```

!!! Note "def create(request)のプログラムについて"
    ModelFormを作成すると、POST(またはGET)された値が、DBに正しく格納できるかチェックすることができます。

    以下は、POSTが正しければDBに書き込むプログラムです。  
    <code>
    form = PostForm(request.POST)  
    if form.is_valid():  
    &nbsp;&nbsp;form.save()  
    </code>

    また、<code>return redirect(reverse('todo:index'))</code>とすることで、対象URLにリダイレクトできます。

!!! Note "def update(request, post_id)のプログラムについて"
    urls.pyで<code>&lt;int:<font color="red">post_id</font>></code>と指定したので、<code>update(request, <font color="red">post_id</font>)</code>のpost_idにIDが格納されています。

    <code>post = get_object_or_404(Post, pk=post_id)</code>は、データが存在しない場合に404エラーを返します。
    
    データが存在した場合、<code>not post.completed</code>で完了状態を入れ替えて、セーブしています。(Falseの場合→True。Trueの場合→False)

!!! Note "def delete(request, post_id)のプログラムについて"
    updateと似たようなプログラムですが、データが存在したら<code>delete()</code>しているだけの簡素なプログラムです。
    
    

## HTMLの修正

todo/templates/todo/index.htmlを、以下のように変更します。
```html hl_lines="2 8 10 22 23 29 31 33 35 38 39 41 42 43 47 51"
<!-- todo/templates/todo/index.html -->
{% load static %}
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="{% static 'todo/css/style.css' %}" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <script src="{% static 'todo/js/moment-with-locales.js' %}"></script>
  <title>Simple ToDo</title>
</head>
<body>
  <header>
    <div>
      <div id="date"></div>
      <div id="time"></div>
    </div>
  </header>

  <main>
    <form class="create" method="post" action="{% url 'todo:create' %}">
      {% csrf_token %}
      <input type="text" name="task">
      <button><i class="material-icons">playlist_add</i>追加</button>
    </form>

    <div class="character">
      <img src="{% static 'todo/img/yuri_normal.png' %}">
    </div>
    {% if message  %}
    <div class="balloon">
      <div>{{ message }}</div>
    </div>
    {% endif %}

    <form id="list" method="post" action="#">
      {% csrf_token %}
      {% for post in posts %}
      <div>
        <input type="text" name="task" class="{{ post.completed|yesno:'line,' }}"
               value="{{ post.task }}" onclick="submitAction('{% url 'todo:update' post.id %}')" readonly>
        <button type="button" onclick="submitAction('{% url 'todo:delete' post.id %}')">
          <i class="material-icons">clear</i>削除
        </button>
      </div>
      {% endfor %}
    </form>
  </main>

  <script src="{% static 'todo/js/main.js' %}"></script>
</body>
</html>
```

!!! Note "load static と url について"
    <code>{% load static %}</code>と記述すると、staticファイルが<code>{% static '対象ファイル' %}</code>で参照できるようになります。

    <code>{% url '<font color="red">todo:</font>create' %}</code>は、urlを取得するプログラムです。  
    <code><font color="red">todo:</font></code>は、urls.pyで指定した<code>app_name = 'todo'</code>です。

!!! Note "form について"
    クロスサイトリクエストフォージェリ(CSRF)を防ぐため、&lt;form>タグには<code>{% csrf_token %}</code>が必須です。  
    無いとエラーになります。

!!! Note "if と for 文について"
    Djangoのテンプレートでは、ifとfor文を以下のように記述します。  
    if文  
    <code>
    {% if 判定ロジック  %}  
    {% endif  %}  
    </code>

    for文  
    <code>
    {% for 処理ロジック %}  
    {% endfor %}
    </code>

<a href="http://localhost:8000">http://localhost:8000</a>にアクセスして、アプリが動作したら完成です。  
<span style="max-width:300px; display:block;">
![](img/simpletodo/completed.png)
</span>


## 最後に
お疲れ様でした。

全ファイルをzipにしたので、もし見たければ[ダウンロード](zip/all.zip)してください。  
(XMaindやAdobe XDのファイルも含まれています)