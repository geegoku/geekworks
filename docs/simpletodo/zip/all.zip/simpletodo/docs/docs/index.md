# Djangoで作るToDo Webアプリ入門<br> 〜マインドマップ作成から完成まで〜

これは「Webアプリのマインドマップ作成から完成までを学ぼう」という入門講座です。
実際のアプリ開発は、Django2(＋Python3)で行います。

!!! note
    この講座では、Pythonの文法については解説していません。  
    もし、Pythonの文法を知りたい場合は、<a href="https://www.pythonweb.jp/tutorial" target="_blank">PythonWeb</a>や<a href="https://dotinstall.com/lessons/basic_python_v3" target="_blank">ドットインストール</a>がお勧めです。  
    また、気軽に筆者へ聞いてくれれば、何でも回答します。　　

この講座を完了すると、以下のようなWebアプリが完成します。  

* ワイヤーフレーム  
![](img/simpletodo/wireframe.svg)

* モックアップ  
![](img/simpletodo/mockup.png)

* 完成  
<span style="width:300px; display:block;">
![](img/simpletodo/completed.png)
</span>

まずは、マインドマップの作成から始めましょう。
