## Djangoとは
Djangoとは、pythonで実装されたフルスタックのWebフレームワークです。
Pythonで一番メジャーなフレームワークになります。

<script type="text/javascript" src="https://ssl.gstatic.com/trends_nrtr/1480_RC02/embed_loader.js"></script> <script type="text/javascript"> trends.embed.renderExploreWidget("TIMESERIES", {"comparisonItem":[{"keyword":"python django","geo":"","time":"today 12-m"},{"keyword":"python flask","geo":"","time":"today 12-m"},{"keyword":"python bottle","geo":"","time":"today 12-m"},{"keyword":"python tornado","geo":"","time":"today 12-m"}],"category":0,"property":""}, {"exploreQuery":"q=python%20django,python%20flask,python%20bottle,python%20tornado&date=today 12-m,today 12-m,today 12-m,today 12-m","guestPath":"https://trends.google.co.jp:443/trends/embed/"}); </script>

## PyCharmの設定
インストールしたPycharmを起動します。
起動したらopenを押して、作成したsimpletodoフォルダを開きます。  

<span style="max-width:600px; display:block;">
![](img/pycharm/open.png)
</span>

開くと、プロジェクトが以下のフォルダ構成になっています。
<span style="max-width:300px; display:block;">
![](img/pycharm/folder.png)
</span>

まず、Interpreterの設定をします。

!!! Windowsの場合
    左上のメニューから、File > Settingsを押して、Settings画面を開きます。  
    Settings画面から、 Project > Project Interpreterを選択。
    右上のギアアイコンから、「Add」を選択します。

!!! Macの場合
    左上のメニューから、PyCharm > Preferencesを押して、Preferences画面を開きます。  
    Preferences画面から、 Project > Project Interpreterを選択。
    右上のギアアイコンから、「Add」を選択します。
![](img/pycharm/interpreter.png)

選択が「New environment」になっていて、「Base interpreter:」が設定されていることを確認してください。
問題なければ、OKボタンを押します。
![](img/pycharm/add-interpreter.png)


OKボタンを押すと、venvというフォルダが作成されています。
この状態で、PyCharm下メニューの「Terminal」をクリックします。
Terminal画面で「(venv)」と表示されていたら、InterpreterとVirtualenvの設定は完了です。  
<span style="max-width:350px; display:block;">
![](img/pycharm/venv.png)
</span>

!!! info "venvとは"
    venvとは、Pythonの仮想環境です。(Virtual environments)  
    コマンドラインドでvenv環境を作る場合、フォルダ名は自由に設定できるのですが、通常venvというフォルダ名にします。  
    <code>
    python -m venv [newenvname]  
    python -m venv venv  
    </code>
    

Terminalで <code>pip list</code> と入力して、Enterキーを押してください。  
すると、新規作成したvenvなので、Django等が入っていない状態なのが分かります。
<span style="max-width:405px; display:block;">
![](img/pycharm/pip-list.png)
</span>

¥!!! Note
    以下のような警告メッセージが表示された場合は、`pip install --upgrade pip`を実行してください。  
    You should consider upgrading via the 'pip install --upgrade pip' command.

それでは、venv環境にDjangoをインストールします。  
```
pip install django
```  
その後、インストールできたことを確認します。  
```
pip list
```
以下のように、Django2.xがインストールされていたら完了です。
<span style="max-width:470px; display:block;">
![](img/pycharm/django.png)
</span>

## Djangoの起動
メニューのRunから、Edit Configurationsを選択。  
Run/Debug Configurations画面で、左上の「+」をクリックし「Python」を選択します。

以下のように設定して、OKボタンを押します。
```html
Name: Django
Script path: manage.py
Parameters: runserver
```
![](img/pycharm/configuration.png)

上メニューの「緑のRunボタン」をクリックすると、Djangoが起動します。  
<span style="max-width:200px; display:block;">
![](img/pycharm/runserver.png)
</span>

localhostにアクセスして、Djangoが起動しているか確認します。  
<span style="max-width:550px; display:block;">
<a href="http://localhost:8000/" target="_blank">
  http://localhost:8000/  
  ![](img/django.png)
</a>
</span>

## Djangoの日本語対応
simpletodo/settings.pyを開いて、最後尾にあるコードを変更します。
``` python hl_lines="4 5"
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
　↓↓↓↓↓
LANGUAGE_CODE = 'ja'
TIME_ZONE = 'Asia/Tokyo'
```

保存するとDjangoが自動で再起動するので、画面が日本語化していたら完了です。

<span style="max-width:550px; display:block;">
![](img/django-ja.png)
</span>

!!! Note
    たまに`LANGUAGE_CODE=ja`ではなく、`LANGUAGE_CODE=ja-jp`と解説しているサイトがありますが、間違いです。  
    日本は日本語しか使わない為、`ja`のみとします。
    
    
## パッケージの書き出し(requirements.txtの作成)
今まで使ってきたpip(ピップ)は、Python用のパッケージ管理ソフトになります。  
「インストールしたパッケージ一覧の書き出し」も可能なので、やっておきましょう。

Terminalで、以下のコマンドを実行してください。
```
pip freeze > requirements.txt
```

すると、以下の内容でrequirements.txtが作成されます。  
```python
Django==2.0.6
pytz==2018.5
```

このrequirements.txtをPyCharmで開くと、(インストールされていなければ)パッケージのインストール確認画面が表示されます。

また、以下のコマンドでも、パッケージを一括インストールすることができます。
```
pip install -r requirements.txt
```

次は、DjangoでHello wolrdを表示してみます。