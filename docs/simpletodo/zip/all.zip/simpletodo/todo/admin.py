from django.contrib import admin

from todo.models import Post

admin.site.register(Post)
