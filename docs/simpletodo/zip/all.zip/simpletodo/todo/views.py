from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from random import randrange

from todo.forms import PostForm
from todo.models import Post

messages = [
    '頑張ってね。応援してるよ！',
    '君はタスク管理が得意な フレンズなんだね',
    'すごーい！',
    'たーのしー！',
    ''
]


def index(request):
    posts = Post.objects.order_by('-created_at')
    if len(posts) == 0:
        message = 'タスクを追加してね'
    else:
        dice = randrange(len(messages))
        message = messages[dice]
    context = {
        'posts': posts,
        'message': message
    }
    return render(request, 'todo/index.html', context)


def create(request):
    form = PostForm(request.POST)
    if form.is_valid():
        form.save()
    return redirect(reverse('todo:index'))


def update(request, post_id):
    post = get_object_or_404(Post, pk=post_id)
    post.completed = not post.completed
    post.save()
    return redirect(reverse('todo:index'))


def delete(request, post_id):
    post = get_object_or_404(Post, pk=post_id)
    post.delete()
    return redirect(reverse('todo:index'))
