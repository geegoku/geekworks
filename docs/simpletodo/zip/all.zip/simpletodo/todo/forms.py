from django.forms import ModelForm

from todo.models import Post


class PostForm(ModelForm):
    class Meta:
        model = Post
        fields = ('task', 'completed')
