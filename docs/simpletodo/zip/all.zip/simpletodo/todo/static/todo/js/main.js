function submitAction(url) {
  console.log(url);
  let list = document.getElementById('list');
  list.action = url;
  list.submit();
}

function clock() {
  document.getElementById('date').innerHTML = moment().format("MM/DD(ddd)");
  document.getElementById('time').innerHTML = moment().format("HH:mm");
}

moment.locale('ja');
clock();
setInterval(clock, 1000);

